# quando eu sei quantas repetições eu tenho que fazer eu uso FOR
#quando eu não sei quantas x eu vou repetir o número eu uso WHILE

#ex04 mega sena

#mplemente um programa em Python para verificar quantos números uma
#aposta acertou na Megasena. O programa deve ler do teclado os 6 números
#apostados e comparar com 6 números sorteados. Ao final o programa deve exibir
#os números sorteados, números jogados e quantidade de acertos.

import random

sorteado = []
digitado = []
acerto = 0

for i in range(6):
    numSorteado = random.randint(1,60)
    while numSorteado in sorteado:
        numSorteado = random.randint(1,60)
    sorteado.append(numSorteado)

for i in range(6):
    numDigitado = int(input("Digite um número: "))
    while (numDigitado in digitado) or (numDigitado < 1) or (numDigitado > 60):
        print("Erro. Número inválido")
        numDigitado = int(input("Digite um número: "))
    digitado.append(numDigitado)

for valor in digitado:
    if valor in sorteado:
        acerto += 1

sorteado.sort()
digitado.sort()

print("Sorteados: ", sorteado)
print("Digitados: ", digitado)
print("Acertos: ", acerto)
